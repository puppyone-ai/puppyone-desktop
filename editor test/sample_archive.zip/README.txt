English ZIP archive preview.
This file is inside the archive.
